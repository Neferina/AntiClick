﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckGround : MonoBehaviour {

	private HeroController hero;
	// Use this for initialization
	void Start () {
		hero = GetComponentInParent<HeroController>();
	}
	
	void OnCollisionStay2D(Collision2D col){
		if(col.gameObject.tag == "Ground"){
			hero.ground = true;
		}
	}
	void OnCollisionExit2D(Collision2D col){
		if(col.gameObject.tag == "Ground"){
			hero.ground = false;
		}
	}
}
